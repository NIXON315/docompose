<?php
session_start();
include_once "libraries/autoload.php";
$lb = new Lb();
$lb->loadModule("index");
?>