<div class="row">
<div class="col-md-12">
<h1>Agenda Personal</h1>
<p>Bienvenido a <b>Yibun</b> un Sistema de Agenda personal.</p>
<h4> v1.0</h4>
<ul>
	<li>Vista de Calendario</li>
	<li>Gestion de Eventos</li>
	<li>Gestion de Proyectos</li>
	<li>Gestion de Categorias</li>
	<li>Buscador avanzado por : Palabra clave, proyecto, Categoria y fecha.</li>
</ul>
<p>Nixon Camilo Anacona Diaz &copy; 2021</p>
</div>
</div>
