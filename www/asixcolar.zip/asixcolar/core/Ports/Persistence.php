<?php 
// Se cambia por el adaptador de persistencia que se requiera
include_once "./core/Adapters/MySQL/boot.php";
?>