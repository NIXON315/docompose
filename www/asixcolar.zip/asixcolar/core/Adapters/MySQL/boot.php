<?php
include_once "./core/adapters/MySQL/AlumnData.php";
include_once "./core/adapters/MySQL/AlumnTeamData.php";
include_once "./core/adapters/MySQL/AssistanceData.php";
include_once "./core/adapters/MySQL/BehaviorData.php";
include_once "./core/adapters/MySQL/BlockData.php";
include_once "./core/adapters/MySQL/CalificationData.php";
include_once "./core/adapters/MySQL/EventData.php";
include_once "./core/adapters/MySQL/PostData.php";
include_once "./core/adapters/MySQL/ProjectData.php";
include_once "./core/adapters/MySQL/TeamData.php";
include_once "./core/adapters/MySQL/UserData.php";

?>