# Asixcolar
Sistema de Administracion de Alumnos, Grupos, asistencia, Comportamiento y Calificaciones para Profesores desarrollado con PHP y MySQL
